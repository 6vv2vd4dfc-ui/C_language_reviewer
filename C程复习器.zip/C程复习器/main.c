#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <windows.h>

#include "quizsource1.h"



// 填空题结构体（选择题结构体已在头文件中定义）
typedef struct {
    int id;          
    char category[50];    
    char question[256];
    char correct_answer[128];
    char user_answer[128];
    int is_correct; 
} FillInBlank;



// 填空题数据（还没整理完）
FillInBlank fill_questions[] = {
    {1, "分支循环数据表达式等", "设x=12，则表达式0<x<10用%d输出的值是：", "1", "", 0},
    {2, "分支循环数据表达式等", "表达式!1100用%d输出的值是：", "1", "", 0},
    {3, "分支循环数据表达式等", "unsigned char类型变量的最大值是【】。", "255", "", 0}
};


int choice_count = sizeof(choice_questions) / sizeof(MultipleChoice);
int fill_count = sizeof(fill_questions) / sizeof(FillInBlank);



void clear_input_buffer();
void display_formatted_text(const char* text);
void display_choice_question(MultipleChoice q);
void display_fill_question(FillInBlank q);
void answer_choice_questions();
void answer_fill_questions();
void display_results();
void main_menu();




// 清除输入缓冲区
void clear_input_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

//显示格式控制 （小登能力有限，换行和制表符输出遭遇了未知问题，故让Ds专门写了个函数/(ㄒoㄒ)/~~
void display_formatted_text(const char* text) {
    const char* p = text;
    while (*p) {
        if (*p == '\\' && *(p + 1) == 'n') {
            printf("\n");
            p += 2;
        } else if (*p == '\\' && *(p + 1) == 't') {
            printf("\t");
            p += 2;
        } else {
            putchar(*p);
            p++;
        }
    }
}

//选择题显示
void display_choice_question(MultipleChoice q) {
    printf("\n==============================\n");
    printf("题目ID: %d\n", q.id);
    printf("类别: %s\n", q.category);
    printf("题目: ");
    display_formatted_text(q.question);
    printf("\n\n");
    
    for (int i = 0; i < 4; i++) {
        printf("%c) %s\n", 'A' + i, q.options[i]);
    }
    printf("\n");
}

// 显示填空题
void display_fill_question(FillInBlank q) {
    printf("\n==============================\n");
    printf("题目ID: %d\n", q.id);
    printf("类别: %s\n", q.category);
    printf("题目: %s\n\n", q.question);
}

// 回答选择题
void answer_choice_questions() {
    printf("\n===== 开始选择题答题 =====\n");
    printf("共有 %d 道选择题\n\n", choice_count);
    int k,flag;
    for (int i = 0; i < choice_count; i++) {
        display_choice_question(choice_questions[i]);
        flag=0;
        char answer;
        int valid_input = 0;
        
        while (!valid_input) {
            printf("请输入你的答案 (A/B/C/D, Q退出/T跳题): ");
            answer = getchar();
            clear_input_buffer();
            answer = toupper(answer);
            
            if(answer=='T'){
            	printf("请输入要跳转的题号：");
            	scanf("%d",&k);
            	flag=1;
			}
            if(flag){
            	i=k-2;
            	break;
			}
            
            if (answer == 'Q') {
                printf("退出答题\n");
                return;
            }
            
            if (answer >= 'A' && answer <= 'D') {
                valid_input = 1;
                choice_questions[i].user_answer = answer;
                
                // 判断是否正确
                if (answer == choice_questions[i].correct_answer) {
                    choice_questions[i].is_correct = 1;
                    printf("✓ 正确！\n");
                } else {
                    choice_questions[i].is_correct = 0;
                    printf("✗ 错误。正确答案是: %c\n", 
                           choice_questions[i].correct_answer);
                }
            } else {
                printf("输入无效，请输入 A、B、C 或 D\n");
            }
        }
        
        printf("\n按回车键继续下一题...");
        getchar();
    }
    
    printf("\n选择题答题结束！\n");
}

// 回答填空题
void answer_fill_questions() {
    printf("\n===== 开始填空题答题 =====\n");
    printf("共有 %d 道填空题\n\n", fill_count);
    
    for (int i = 0; i < fill_count; i++) {
        display_fill_question(fill_questions[i]);
        
        printf("请输入你的答案: ");
        fgets(fill_questions[i].user_answer, 
              sizeof(fill_questions[i].user_answer), stdin);
        
        // 去除换行符
        size_t len = strlen(fill_questions[i].user_answer);
        if (len > 0 && fill_questions[i].user_answer[len-1] == '\n') {
            fill_questions[i].user_answer[len-1] = '\0';
        }
        
        // 判断是否正确（简单字符串比较）
        if (strcmp(fill_questions[i].user_answer, 
                   fill_questions[i].correct_answer) == 0) {
            fill_questions[i].is_correct = 1;
            printf("✓ 正确！\n");
        } else {
            fill_questions[i].is_correct = 0;
            printf("✗ 错误。正确答案是: %s\n", 
                   fill_questions[i].correct_answer);
        }
        
        printf("\n按回车键继续下一题...");
        getchar();
    }
    
    printf("\n填空题答题结束！\n");
}

// 显示答题结果
void display_results() {
    printf("\n===== 答题结果统计 =====\n");
    
    // 选择题统计
    int choice_correct = 0;
    printf("\n【选择题统计】\n");
    printf("总题数: %d\n", choice_count);
    
    for (int i = 0; i < choice_count; i++) {
        if (choice_questions[i].is_correct) {
            choice_correct++;
        }
        
        printf("\n题目 %d: ", choice_questions[i].id);
        if (choice_questions[i].user_answer != ' ') {
            printf("你的答案: %c, ", choice_questions[i].user_answer);
            printf("正确答案: %c, ", choice_questions[i].correct_answer);
            printf(choice_questions[i].is_correct ? "✓ 正确" : "✗ 错误");
        } else {
            printf("未作答");
        }
    }
    
    printf("\n选择题正确数: %d/%d (%.1f%%)\n", 
           choice_correct, choice_count,
           choice_count > 0 ? (float)choice_correct / choice_count * 100 : 0);
    
    // 填空题统计
    int fill_correct = 0;
    printf("\n【填空题统计】\n");
    printf("总题数: %d\n", fill_count);
    
    for (int i = 0; i < fill_count; i++) {
        if (fill_questions[i].is_correct) {
            fill_correct++;
        }
        
        printf("\n题目 %d: ", fill_questions[i].id);
        if (strlen(fill_questions[i].user_answer) > 0) {
            printf("你的答案: %s, ", fill_questions[i].user_answer);
            printf("正确答案: %s, ", fill_questions[i].correct_answer);
            printf(fill_questions[i].is_correct ? "✓ 正确" : "✗ 错误");
        } else {
            printf("未作答");
        }
    }
    
    printf("\n填空题正确数: %d/%d (%.1f%%)\n", 
           fill_correct, fill_count,
           fill_count > 0 ? (float)fill_correct / fill_count * 100 : 0);
    
    // 总统计
    printf("\n【总统计】\n");
    int total_questions = choice_count + fill_count;
    int total_correct = choice_correct + fill_correct;
    printf("总题数: %d\n", total_questions);
    printf("总正确数: %d\n", total_correct);
    printf("总正确率: %.1f%%\n", 
           total_questions > 0 ? (float)total_correct / total_questions * 100 : 0);
}

// 主菜单
void main_menu() {
    int choice;
    
    do {
        printf("\n===== C语言理论作业答题系统 =====\n");
        printf("1. 回答选择题\n");
        printf("2. 回答填空题\n");
        printf("3. 查看答题结果\n");
        printf("4. 退出系统\n");
        printf("请选择: ");
        
        if (scanf("%d", &choice) != 1) {
            printf("输入无效，请重新输入！\n");
            clear_input_buffer();
            continue;
        }
        clear_input_buffer();
        
        if(choice==2){
        	printf("\n非常抱歉，还在调试o(TヘTo)!\n");
        	continue;
		}
        
        switch (choice) {
            case 1:
                answer_choice_questions();
                break;
            case 2:
                answer_fill_questions();
                break;
            case 3:
                display_results();
                break;
            case 4:
                printf("退出系统，再见！\n");
                break;
            default:
                printf("无效选择，请重新输入！\n");
        }
    } while (choice != 4);
}



int main() {
    SetConsoleOutputCP(CP_UTF8);
    printf("欢迎使用C语言理论作业答题系统\n本系统由Deepseek&喂z共同写成，题目来源所在班级老师提供，仅作学习使用，请勿商用，谢谢配合！\n\n欢迎纠错和建议ヾ(≧▽≦*)o\nand部分功能还在完善中＞︿＜\n\n");
    printf("本系统包含以下题集：\n");
    printf("1. 分支循环数据表达式等四个篇章(共 %d 道选择题)\n", choice_count);
    printf("2. 填空题 (共 %d 道)\n", fill_count);
    
    main_menu();
    
    return 0;
}